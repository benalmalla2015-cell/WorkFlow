<?php

namespace App\Services;

use App\Models\AuditLog;
use App\Models\Order;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use PhpOffice\PhpSpreadsheet\IOFactory as SpreadsheetIOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpWord\IOFactory as WordIOFactory;
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\SimpleType\Jc;
use PhpOffice\PhpWord\SimpleType\JcTable;
use PhpOffice\PhpWord\TemplateProcessor;

class WorkflowDocumentService
{
    public function generateQuotation(Order $order): array
    {
        $order = $this->loadOrder($order);
        $items = $this->resolveItems($order);

        if ($items === []) {
            throw ValidationException::withMessages([
                'items' => 'Order must contain at least one item.',
            ]);
        }

        $disk = config('workflow.documents_disk', 'public');
        $root = trim(config('workflow.quotations_root', 'quotations'), '/');
        $filename = 'quotation_' . $order->order_number . '_' . now()->format('Ymd_His') . '.xlsx';
        $relativePath = $root . '/' . $filename;

        $this->ensureDirectory($disk, $root);

        $spreadsheet = SpreadsheetIOFactory::load($this->ensureExcelTemplate());
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('C5', $this->resolveCustomerName($order));
        $sheet->setCellValue('C6', now()->format('Y-m-d'));

        $row = 10;
        foreach ($items as $index => $item) {
            $sheet->setCellValue('A' . $row, $index + 1);
            $sheet->setCellValue('B' . $row, $item['item_name']);
            $sheet->setCellValue('C' . $row, $item['quantity']);
            $sheet->setCellValue('D' . $row, $item['description']);
            $row++;
        }

        $writer = SpreadsheetIOFactory::createWriter($spreadsheet, 'Xlsx');
        $writer->save(Storage::disk($disk)->path($relativePath));

        $order->update(['quotation_path' => $relativePath]);
        AuditLog::log('quotation_generated', $order);

        return [
            'filename' => $filename,
            'path' => $relativePath,
        ];
    }

    public function generateInvoice(Order $order): array
    {
        $order = $this->loadOrder($order);
        $items = $this->resolveItems($order);

        if ($items === []) {
            throw ValidationException::withMessages([
                'items' => 'Order must contain at least one item.',
            ]);
        }

        $disk = config('workflow.documents_disk', 'public');
        $root = trim(config('workflow.invoices_root', 'invoices'), '/');
        $filename = 'workflow_' . $order->order_number . '_' . now()->format('Ymd_His') . '.docx';
        $relativePath = $root . '/' . $filename;

        $this->ensureDirectory($disk, $root);

        $template = new TemplateProcessor($this->ensureWordTemplate());
        $template->setValue('customer_name', $this->sanitizeTemplateValue($this->resolveCustomerName($order)));
        $template->setValue('date', now()->format('Y-m-d'));
        $template->setValue('order_number', $this->sanitizeTemplateValue($order->order_number));
        $template->setValue('verification_url', $this->sanitizeTemplateValue($this->verificationUrl($order)));
        $template->cloneRow('item_name', count($items));

        foreach ($items as $index => $item) {
            $rowNumber = $index + 1;
            $template->setValue('item_name#' . $rowNumber, $this->sanitizeTemplateValue($item['item_name']));
            $template->setValue('quantity#' . $rowNumber, (string) $item['quantity']);
            $template->setValue('description#' . $rowNumber, $this->sanitizeTemplateValue($item['description']));
        }

        $template->saveAs(Storage::disk($disk)->path($relativePath));

        $order->update(['invoice_path' => $relativePath]);
        AuditLog::log('invoice_generated', $order);

        return [
            'filename' => $filename,
            'path' => $relativePath,
        ];
    }

    public function verificationUrl(Order $order): string
    {
        return route('orders.verify', ['orderNumber' => $order->order_number]);
    }

    private function loadOrder(Order $order): Order
    {
        return Order::withoutGlobalScopes()
            ->with(['customer', 'salesUser', 'items'])
            ->findOrFail($order->id);
    }

    private function resolveCustomerName(Order $order): string
    {
        return (string) ($order->resolvedCustomerName() ?: 'N/A');
    }

    private function resolveItems(Order $order): array
    {
        return $order->resolvedItems()
            ->map(function ($item) {
                return [
                    'item_name' => (string) ($item->item_name ?? ''),
                    'quantity' => max(1, (int) ($item->quantity ?? 1)),
                    'description' => (string) ($item->description ?? ''),
                ];
            })
            ->filter(fn ($item) => $item['item_name'] !== '')
            ->values()
            ->all();
    }

    private function sanitizeTemplateValue(?string $value): string
    {
        return trim(str_replace(["\r\n", "\r", "\n"], ' | ', (string) $value));
    }

    private function ensureDirectory(string $disk, string $root): void
    {
        if (!Storage::disk($disk)->exists($root)) {
            Storage::disk($disk)->makeDirectory($root);
        }
    }

    private function ensureWordTemplate(): string
    {
        $disk = config('workflow.templates_disk', 'local');
        $root = trim(config('workflow.templates_root', 'templates'), '/');
        $relativePath = $root . '/' . config('workflow.word_template_name', 'workflow_template.docx');
        $absolutePath = Storage::disk($disk)->path($relativePath);

        $this->ensureDirectory($disk, $root);

        if (file_exists($absolutePath)) {
            return $absolutePath;
        }

        $phpWord = new PhpWord();
        $phpWord->setDefaultFontName('Arial');
        $phpWord->setDefaultFontSize(11);

        $section = $phpWord->addSection([
            'marginTop' => 700,
            'marginBottom' => 700,
            'marginLeft' => 700,
            'marginRight' => 700,
        ]);

        $section->addText('Workflow Management System', ['bold' => true, 'size' => 16], ['alignment' => Jc::CENTER]);
        $section->addText('Customer Name: ${customer_name}');
        $section->addText('Date: ${date}');
        $section->addText('Order Number: ${order_number}');
        $section->addText('Verification URL: ${verification_url}');
        $section->addTextBreak(1);

        $table = $section->addTable([
            'borderSize' => 6,
            'borderColor' => '999999',
            'alignment' => JcTable::CENTER,
            'cellMargin' => 80,
        ]);

        $table->addRow();
        $table->addCell(4500)->addText('Item Name', ['bold' => true]);
        $table->addCell(1800)->addText('Quantity', ['bold' => true]);
        $table->addCell(5500)->addText('Description', ['bold' => true]);

        $table->addRow();
        $table->addCell(4500)->addText('${item_name}');
        $table->addCell(1800)->addText('${quantity}');
        $table->addCell(5500)->addText('${description}');

        $writer = WordIOFactory::createWriter($phpWord, 'Word2007');
        $writer->save($absolutePath);

        return $absolutePath;
    }

    private function ensureExcelTemplate(): string
    {
        $disk = config('workflow.templates_disk', 'local');
        $root = trim(config('workflow.templates_root', 'templates'), '/');
        $relativePath = $root . '/' . config('workflow.excel_template_name', 'workflow_template.xlsx');
        $absolutePath = Storage::disk($disk)->path($relativePath);

        $this->ensureDirectory($disk, $root);

        if (file_exists($absolutePath)) {
            return $absolutePath;
        }

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Workflow');

        $sheet->mergeCells('B3:D3');
        $sheet->setCellValue('B3', 'Workflow Management System');
        $sheet->setCellValue('B5', 'Customer Name');
        $sheet->setCellValue('B6', 'Date');
        $sheet->setCellValue('A9', '#');
        $sheet->setCellValue('B9', 'Item Name');
        $sheet->setCellValue('C9', 'Quantity');
        $sheet->setCellValue('D9', 'Description');

        $sheet->getStyle('B3:D3')->getFont()->setBold(true)->setSize(15);
        $sheet->getStyle('A9:D9')->getFont()->setBold(true);
        $sheet->getStyle('A9:D9')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A9:D9')->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
        $sheet->getColumnDimension('A')->setWidth(8);
        $sheet->getColumnDimension('B')->setWidth(30);
        $sheet->getColumnDimension('C')->setWidth(14);
        $sheet->getColumnDimension('D')->setWidth(50);

        $writer = SpreadsheetIOFactory::createWriter($spreadsheet, 'Xlsx');
        $writer->save($absolutePath);

        return $absolutePath;
    }
}
