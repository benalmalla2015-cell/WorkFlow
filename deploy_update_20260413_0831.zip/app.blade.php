<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    @php
        $pageTitle = trim($__env->yieldContent('title'));
        $pageTitle = $pageTitle !== ''
            ? str_replace(' | WorkFlow', '', $pageTitle) . ' | نظام إدارة سير العمل | شركة ديانكو التجارية'
            : 'نظام إدارة سير العمل | شركة ديانكو التجارية';
    @endphp
    <title>{{ $pageTitle }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        body { background: #f5f7fb; color: #1f2937; text-align: right; }
        .portal-shell { min-height: 100vh; display: flex; }
        .portal-sidebar { width: 280px; background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%); color: #fff; padding: 24px 18px; position: sticky; top: 0; height: 100vh; }
        .portal-sidebar a { color: rgba(255,255,255,.82); text-decoration: none; display: block; padding: 12px 14px; border-radius: 12px; margin-bottom: 8px; font-weight: 500; }
        .portal-sidebar a.active, .portal-sidebar a:hover { background: rgba(255,255,255,.1); color: #fff; }
        .portal-brand { font-size: 1.4rem; font-weight: 700; margin-bottom: 4px; }
        .portal-tagline { color: rgba(255,255,255,.62); font-size: .92rem; margin-bottom: 28px; }
        .portal-main { flex: 1; display: flex; flex-direction: column; min-width: 0; }
        .portal-header { background: #fff; border-bottom: 1px solid #e5e7eb; padding: 18px 28px; display: flex; justify-content: space-between; align-items: center; gap: 16px; }
        .portal-content { padding: 28px; }
        .page-card { border: 0; border-radius: 18px; box-shadow: 0 14px 42px rgba(15, 23, 42, .08); }
        .stat-card { border: 0; border-radius: 18px; box-shadow: 0 14px 38px rgba(15, 23, 42, .06); }
        .section-title { font-weight: 700; margin-bottom: 1rem; }
        .table thead th { background: #f8fafc; color: #334155; font-size: .88rem; white-space: nowrap; }
        .badge-status { display: inline-flex; align-items: center; gap: 6px; border-radius: 999px; padding: 6px 12px; font-size: .78rem; font-weight: 700; }
        .status-draft { background: #e2e8f0; color: #334155; }
        .status-factory_pricing { background: #dbeafe; color: #1d4ed8; }
        .status-manager_review { background: #fef3c7; color: #b45309; }
        .status-pending_approval { background: #fee2e2; color: #b91c1c; }
        .status-approved { background: #dcfce7; color: #15803d; }
        .status-customer_approved { background: #cffafe; color: #0f766e; }
        .status-payment_confirmed { background: #d1fae5; color: #047857; }
        .status-completed { background: #ede9fe; color: #6d28d9; }
        .form-card { border: 0; border-radius: 18px; box-shadow: 0 12px 34px rgba(15, 23, 42, .06); }
        .attachment-list a { text-decoration: none; }
        .chart-card canvas { max-height: 320px; }
        .portal-footer { padding: 0 28px 24px; color: #64748b; font-size: .9rem; text-align: center; }
        .notification-bell { position: relative; width: 42px; height: 42px; border-radius: 999px; display: inline-flex; align-items: center; justify-content: center; }
        .notification-dot { position: absolute; top: 8px; left: 9px; width: 10px; height: 10px; border-radius: 999px; background: #dc2626; border: 2px solid #fff; }
        .notification-menu { width: min(420px, 92vw); padding: 0; border: 0; border-radius: 18px; box-shadow: 0 24px 60px rgba(15, 23, 42, .18); overflow: hidden; }
        .notification-menu .dropdown-header { display: flex; justify-content: space-between; align-items: center; padding: 16px 18px; background: #f8fafc; }
        .notification-item { padding: 14px 18px; border-bottom: 1px solid #eef2f7; }
        .notification-item.unread { background: #eff6ff; }
        .notification-item:last-child { border-bottom: 0; }
        @media (max-width: 991.98px) {
            .portal-shell { display: block; }
            .portal-sidebar { width: 100%; height: auto; position: relative; }
            .portal-header, .portal-content { padding: 18px; }
            .portal-footer { padding: 0 18px 18px; }
        }
    </style>
    @stack('styles')
</head>
<body>
    @php
        $user = auth()->user();
        $links = [];
        $recentNotifications = $user?->notifications()->latest()->limit(5)->get() ?? collect();
        $unreadNotificationsCount = $user?->unreadNotifications()->count() ?? 0;

        if ($user?->isAdmin()) {
            $links = [
                ['label' => 'لوحة الإدارة', 'route' => 'admin.dashboard'],
                ['label' => 'إدارة المستخدمين', 'route' => 'admin.users.index'],
                ['label' => 'الإعدادات', 'route' => 'admin.settings.index'],
                ['label' => 'السجلات', 'route' => 'admin.audit-logs.index'],
            ];
        } elseif ($user?->isFactory()) {
            $links = [
                ['label' => 'طلبات المصنع', 'route' => 'factory.orders.index'],
            ];
        } elseif ($user) {
            $links = [
                ['label' => 'طلبات المبيعات', 'route' => 'sales.orders.index'],
                ['label' => 'طلب جديد', 'route' => 'sales.orders.create'],
            ];
        }
    @endphp

    <div class="portal-shell">
        <aside class="portal-sidebar">
            <div class="portal-brand">شركة ديانكو التجارية</div>
            <div class="portal-tagline">نظام إدارة سير العمل | شركة ديانكو التجارية</div>

            @foreach ($links as $link)
                <a href="{{ route($link['route']) }}" class="{{ request()->routeIs(str_replace('.index', '.*', $link['route'])) || request()->routeIs($link['route']) ? 'active' : '' }}">
                    {{ $link['label'] }}
                </a>
            @endforeach
        </aside>

        <main class="portal-main">
            <header class="portal-header">
                <div>
                    <div class="fw-bold">{{ auth()->user()->name }}</div>
                    <div class="text-muted small text-uppercase">{{ auth()->user()->role }}</div>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary notification-bell" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2Zm.104-14.804A1 1 0 0 0 7 2v.278a4.998 4.998 0 0 0-3 4.584V9.5c0 .628-.134 1.197-.352 1.692-.214.486-.527.897-.916 1.216A.5.5 0 0 0 3 13h10a.5.5 0 0 0 .268-.592 3.64 3.64 0 0 1-.916-1.216A4.49 4.49 0 0 1 12 9.5V6.862a4.998 4.998 0 0 0-3-4.584V2a1 1 0 0 0-.896-.804Z"/>
                            </svg>
                            @if ($unreadNotificationsCount > 0)
                                <span class="notification-dot"></span>
                            @endif
                        </button>
                        <div class="dropdown-menu dropdown-menu-end notification-menu">
                            <div class="dropdown-header">
                                <div>
                                    <div class="fw-semibold">الإشعارات</div>
                                    <div class="small text-muted">آخر 5 تنبيهات</div>
                                </div>
                                @if ($unreadNotificationsCount > 0)
                                    <form method="POST" action="{{ route('notifications.read-all') }}">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-link text-decoration-none">تعليم الكل كمقروء</button>
                                    </form>
                                @endif
                            </div>
                            @forelse ($recentNotifications as $notification)
                                @php
                                    $data = $notification->data;
                                    $targetUrl = $data['url'] ?? route('dashboard');
                                @endphp
                                <div class="notification-item {{ $notification->read_at ? '' : 'unread' }}">
                                    <div class="d-flex justify-content-between align-items-start gap-3">
                                        <div>
                                            <div class="fw-semibold">{{ $data['title'] ?? 'تنبيه جديد' }}</div>
                                            <div class="small text-muted">{{ $data['message'] ?? '' }}</div>
                                            @if (!empty($data['reason']))
                                                <div class="small text-danger mt-1">سبب القرار: {{ $data['reason'] }}</div>
                                            @endif
                                            <div class="small text-muted mt-2">{{ optional($notification->created_at)->diffForHumans() }}</div>
                                        </div>
                                        <div class="d-flex flex-column gap-2">
                                            <a href="{{ route('notifications.open', $notification->id) }}" class="btn btn-sm btn-outline-primary">فتح</a>
                                            @if (!$notification->read_at)
                                                <form method="POST" action="{{ route('notifications.read', $notification->id) }}">
                                                    @csrf
                                                    <button type="submit" class="btn btn-sm btn-outline-secondary">مقروء</button>
                                                </form>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <div class="notification-item">
                                    <div class="text-muted small">لا توجد إشعارات حالياً.</div>
                                </div>
                            @endforelse
                        </div>
                    </div>
                    <a href="{{ route('dashboard') }}" class="btn btn-outline-secondary btn-sm">الرئيسية</a>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="btn btn-dark btn-sm">تسجيل الخروج</button>
                    </form>
                </div>
            </header>

            <section class="portal-content">
                @if (session('success'))
                    <div class="alert alert-success border-0 shadow-sm">{{ session('success') }}</div>
                @endif

                @if (session('error'))
                    <div class="alert alert-danger border-0 shadow-sm">{{ session('error') }}</div>
                @endif

                @if ($errors->any())
                    <div class="alert alert-danger border-0 shadow-sm">
                        <div class="fw-semibold mb-2">تعذر إتمام العملية:</div>
                        <ul class="mb-0 ps-3">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                @yield('content')
            </section>

            <footer class="portal-footer">نظام إدارة سير العمل | شركة ديانكو التجارية</footer>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    @stack('scripts')
</body>
</html>
