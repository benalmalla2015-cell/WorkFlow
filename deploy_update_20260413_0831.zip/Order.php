<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'order_number',
        'customer_id',
        'customer_name',
        'sales_user_id',
        'factory_user_id',
        'customer_notes',
        'product_name',
        'quantity',
        'specifications',
        'supplier_name',
        'product_code',
        'factory_cost',
        'production_days',
        'selling_price',
        'profit_margin_percentage',
        'final_price',
        'status',
        'pending_changes',
        'pending_change_requested_by',
        'pending_change_requested_at',
        'pending_change_original_status',
        'customer_approval',
        'payment_confirmed',
        'manager_approval',
        'quotation_path',
        'invoice_path',
        'qr_code_path',
    ];

    protected $casts = [
        'profit_margin_percentage' => 'decimal:2',
        'pending_changes' => 'array',
        'pending_change_requested_at' => 'datetime',
        'customer_approval' => 'boolean',
        'payment_confirmed' => 'boolean',
        'manager_approval' => 'boolean',
    ];

    protected static function booted()
    {
        static::addGlobalScope('privacy', function ($builder) {
            $user = Auth::user();

            if (!$user) {
                return $builder;
            }

            if ($user->isSales()) {
                $builder->select([
                    'id',
                    'order_number',
                    'customer_id',
                    'customer_name',
                    'sales_user_id',
                    'customer_notes',
                    'product_name',
                    'quantity',
                    'specifications',
                    'selling_price',
                    'final_price',
                    'status',
                    'pending_changes',
                    'pending_change_requested_by',
                    'pending_change_requested_at',
                    'pending_change_original_status',
                    'customer_approval',
                    'payment_confirmed',
                    'manager_approval',
                    'quotation_path',
                    'invoice_path',
                    'qr_code_path',
                    'created_at',
                    'updated_at',
                ]);
            }

            if ($user->isFactory()) {
                $builder->select([
                    'id',
                    'order_number',
                    'sales_user_id',
                    'factory_user_id',
                    'product_name',
                    'quantity',
                    'specifications',
                    'supplier_name',
                    'product_code',
                    'factory_cost',
                    'production_days',
                    'status',
                    'pending_changes',
                    'pending_change_requested_by',
                    'pending_change_requested_at',
                    'pending_change_original_status',
                    'created_at',
                    'updated_at',
                ]);
            }
        });
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function salesUser()
    {
        return $this->belongsTo(User::class, 'sales_user_id');
    }

    public function factoryUser()
    {
        return $this->belongsTo(User::class, 'factory_user_id');
    }

    public function pendingChangeRequester()
    {
        return $this->belongsTo(User::class, 'pending_change_requested_by');
    }

    public function attachments()
    {
        return $this->hasMany(Attachment::class);
    }

    public function salesAttachments()
    {
        return $this->attachments()->where('type', 'sales_upload');
    }

    public function factoryAttachments()
    {
        return $this->attachments()->where('type', 'factory_upload');
    }

    public function items()
    {
        return $this->hasMany(OrderItem::class)->orderBy('id');
    }

    public function setSupplierNameAttribute($value)
    {
        $this->attributes['supplier_name'] = Crypt::encrypt($value);
    }

    public function getSupplierNameAttribute($value)
    {
        return $value ? Crypt::decrypt($value) : null;
    }

    public function setFactoryCostAttribute($value)
    {
        $this->attributes['factory_cost'] = $value ? Crypt::encrypt($value) : null;
    }

    public function getFactoryCostAttribute($value)
    {
        return $value ? Crypt::decrypt($value) : null;
    }

    public function setSellingPriceAttribute($value)
    {
        $this->attributes['selling_price'] = $value ? Crypt::encrypt($value) : null;
    }

    public function getSellingPriceAttribute($value)
    {
        return $value ? Crypt::decrypt($value) : null;
    }

    public function setFinalPriceAttribute($value)
    {
        $this->attributes['final_price'] = $value ? Crypt::encrypt($value) : null;
    }

    public function getFinalPriceAttribute($value)
    {
        return $value ? Crypt::decrypt($value) : null;
    }

    public function setCustomerNotesAttribute($value)
    {
        $this->attributes['customer_notes'] = $value ? Crypt::encrypt($value) : null;
    }

    public function getCustomerNotesAttribute($value)
    {
        return $value ? Crypt::decrypt($value) : null;
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'draft' => 'New',
            'factory_pricing', 'manager_review' => 'Processing',
            'pending_approval' => 'Pending Approval',
            'approved', 'customer_approved', 'payment_confirmed' => 'Ready',
            'completed' => 'Completed',
            default => ucwords(str_replace('_', ' ', $this->status)),
        };
    }

    public function getWorkflowStageAttribute(): string
    {
        return match ($this->status) {
            'draft' => 'new',
            'factory_pricing', 'manager_review', 'pending_approval' => 'processing',
            'approved', 'customer_approved', 'payment_confirmed' => 'ready',
            'completed' => 'completed',
            default => 'new',
        };
    }

    public function resolvedCustomerName(): ?string
    {
        if ($this->customer_name) {
            return $this->customer_name;
        }

        if ($this->relationLoaded('customer')) {
            return optional($this->customer)->full_name;
        }

        return optional($this->customer)->full_name;
    }

    public function resolvedItems()
    {
        $items = $this->relationLoaded('items') ? $this->items : $this->items()->get();

        if ($items->isNotEmpty()) {
            return $items;
        }

        return collect([
            new OrderItem([
                'item_name' => $this->product_name,
                'quantity' => $this->quantity,
                'description' => $this->specifications,
            ]),
        ])->filter(fn ($item) => filled($item->item_name));
    }

    public function isDraft()
    {
        return $this->status === 'draft';
    }

    public function isFactoryPricing()
    {
        return $this->status === 'factory_pricing';
    }

    public function isManagerReview()
    {
        return $this->status === 'manager_review';
    }

    public function isPendingApproval()
    {
        return $this->status === 'pending_approval';
    }

    public function isApproved()
    {
        return $this->status === 'approved';
    }

    public function isCustomerApproved()
    {
        return $this->status === 'customer_approved';
    }

    public function isPaymentConfirmed()
    {
        return in_array($this->status, ['payment_confirmed', 'completed'], true);
    }

    public function isCompleted()
    {
        return $this->status === 'completed';
    }

    public function hasPendingChanges(): bool
    {
        return !empty($this->pending_changes);
    }

    public function isLockedForNonAdmin(): bool
    {
        return in_array($this->status, ['approved', 'customer_approved', 'payment_confirmed', 'completed'], true);
    }

    public function canBeEditedBy($user)
    {
        if ($user->isAdmin()) {
            return true;
        }

        if ($this->isLockedForNonAdmin() || $this->hasPendingChanges()) {
            return false;
        }

        if ($user->isSales() && $this->sales_user_id === $user->id) {
            return true;
        }

        if ($user->isFactory()) {
            return $this->factory_user_id === $user->id || $this->status === 'factory_pricing';
        }

        return false;
    }
}
